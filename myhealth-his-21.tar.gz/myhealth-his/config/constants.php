<?php

return [
    'GENDER_ENUM'=>['MALE'=>'Male','FEMALE'=>'Female'],
    'MARITAL_STATUS'=>['SINGLE'=>'Single','MARRIED'=>'Married','WIDOWED'=>'Widowed','DIVORCED'=>'Divorced','SEPRATED'=>'Seprated'],
    'BLOOD_GROUP'=>['A+VE'=>'A+ve','B+VE'=>'B+ve','AB+VE'=>'AB+ve','O+VE'=>'O+ve','O-VE'=>'O-ve'],
    'RELIGION'=>['HINDU'=>'Hindu','ISLAM'=>'Islam','CHRISTIAN'=>'Christian','SIKH'=>'Sikh','BUDDHISTH'=>'Buddhidth','JAIN'=>'Jain','OTHER'=>'Other'],
    'ID_TYPE'=>['AADHAR CARD'=>'Aadhar card','PAN CARD'=>'PAN card','ELECTION CARD'=>'Election card','PASSPORT'=>'Passport'],
    'ALLERGIES_TYPE'=>['FOOD ALLERGIES'=>'Food Allergies','SEASONAL ALLERGIES'=>'Seasonal Allergies','PET ALLERGIES'=>'Pet Allergies','DRUG ALLERGIES'=>'Drug Allergies','OTHER'=>'Other','NA'=>'NA'],
    'MRN_ALPHA'=>'MYHCAH',
    'VN_ALPHA'=>'MYHCAHVN',
    "PATIENT_PROFILE_PIC_PATH"=>'/uploads/profile_pictures/',
];