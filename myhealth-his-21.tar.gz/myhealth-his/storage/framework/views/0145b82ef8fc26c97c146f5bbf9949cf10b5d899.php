<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
</div>


