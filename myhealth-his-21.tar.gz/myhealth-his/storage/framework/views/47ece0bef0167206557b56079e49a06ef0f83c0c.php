<?php $__env->startSection('title', 'Edit Patient'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Patient</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Edit Patient #<?php echo e($patient->id); ?></div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/patient')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php echo Form::model($patient, [
                            'id'=>'patient_register',
                            'method' => 'PATCH',
                            'url' => ['/patient', $patient->id],
                            'class' => 'form-horizontal',
                            'files' => true
                        ]); ?>


                        <?php echo $__env->make('patient_information.form', ['submitButtonText' => 'Update','pageType' =>'edit'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>