<?php $__env->startSection('title','Patient Profile'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Patient Profile</h1>
<?php $__env->stopSection(); ?>
<style type="text/css">
	.profile-img{max-width: 150px; border: 5px solid #fff; box-shadow: 0 2px 2px rgba(0,0,0,0.2);border-radius: 100%;}
</style>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="panel panel-default">
			<a href="<?php echo e(url('/patient')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/patient/' . $patient->id . '/edit')); ?>" title="Edit Member"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
			<div class="panel-body text-center">
				
				<img src="<?php echo e($patient->profile_pic_url); ?>" class="profile-img">
				<h1><?php echo e($patient->first_name.' '.$patient->last_name); ?></h1>
				<h5><?php echo e($patient->patientContact->email); ?></h5>
				<h5><?php echo e($patient->dob); ?> </h5>
				<div class="table-responsive">
	                <table class="table table-borderless">
	                    <tbody>
	                    	<tr><td colspan="2"><h3>Basic Information</h3></td></tr>
	                        <tr><th> Guardian Name </th><td> <?php echo e($patient->guardian_name); ?> </td></tr>
	                        <tr><th> Gender </th><td> <?php echo e($patient->gender); ?> </td></tr>
	                        <tr><th> Marital Status </th><td> <?php echo e($patient->marital_status); ?> </td></tr>
	                        <tr><th> Blood Group </th><td> <?php echo e($patient->blood_group); ?> </td></tr>
	                        <tr><th> Religion </th><td> <?php echo e($patient->religion); ?> </td></tr>
	                        <tr><th> Occupation </th><td> <?php echo e($patient->occupation); ?> </td></tr>
	                        <tr><th> Organization Name </th><td> <?php echo e($patient->organization_name); ?> </td></tr>
	                        <tr><td colspan="2"><h3>Contact Details</h3></th></tr>
	                        <tr><th> Current Address </th><td> <?php echo e($patient->patientContact->current_address); ?> </td></tr>
	                        <tr><th> Country </th><td> <?php echo e($patient->patientContact->country->name); ?> </td></tr>
	                        <tr><th> State </th><td> <?php echo e($patient->patientContact->state->name); ?> </td></tr>
	                        <tr><th> City </th><td> <?php echo e($patient->patientContact->city->name); ?> </td></tr>
	                        <tr><th> Current City Pincode </th><td> <?php echo e($patient->current_pincode); ?> </td></tr>
	                        <tr><th> Permanent Address </th><td> <?php echo e($patient->patientContact->permanent_address); ?> </td></tr>
	                        <tr><th> Permanent Country </th><td> <?php echo e($patient->patientContact->permanentCountry->name); ?> </td></tr>
	                        <tr><th> Permanent State </th><td> <?php echo e($patient->patientContact->permanentState->name); ?> </td></tr>
	                        <tr><th> Permanent City </th><td> <?php echo e($patient->patientContact->permanentCity->name); ?> </td></tr>
	                        <tr><th> Permanent Pincode </th><td> <?php echo e($patient->patientContact->permanent_pincode); ?> </td></tr>
	                        <tr><th> Phone Number </th><td> <?php echo e($patient->patientContact->phone_number); ?> </td></tr>
	                        <tr><th> Alt. Phone Number </th><td> <?php echo e($patient->patientContact->alt_phone_number); ?> </td></tr>
	                        <tr><th> Nationality </th><td> <?php echo e($patient->patientContact->nationality); ?> </td></tr>
	                        <tr><th> Id Type </th><td> <?php echo e($patient->patientContact->id_type); ?> </td></tr>
	                        <tr><th> Id Number </th><td> <?php echo e($patient->patientContact->id_number); ?> </td></tr>
	                        <tr><td colspan="2"><h3>Insurnace Details</h3></th></tr>
	                        <tr><th> Guarantor Name </th><td> <?php echo e($patient->patientInsurance->garentor_name); ?> </td></tr>
	                        <tr><th> Guarantor Gender </th><td> <?php echo e($patient->patientInsurance->garentor_gender); ?> </td></tr>
	                        <tr><th> Guarantor Relation </th><td> <?php echo e($patient->patientInsurance->garentor_relation); ?> </td></tr>
	                        <tr><th> national_id </th><td> <?php echo e($patient->patientInsurance->national_id); ?> </td></tr>
	                        <tr><th> Policy Number </th><td> <?php echo e($patient->patientInsurance->policy_number); ?> </td></tr>
	                        <tr><th> Policy Name </th><td> <?php echo e($patient->patientInsurance->policy_name); ?> </td></tr>
	                        <tr><th> Agency Name </th><td> <?php echo e($patient->patientInsurance->agency); ?> </td></tr>
	                        <tr><td colspan="2"><h3>Health Issues</h3></td></tr>
	                        <tr><th> Allergies Type </th><td> <?php echo e($patient->patientHealthDetail->allergies_type); ?> </td></tr>
	                        <tr><th> Allergens </th><td> <?php echo e($patient->patientHealthDetail->allergens); ?> </td></tr>
	                        <tr><th> Medical History </th><td> <?php echo e($patient->patientHealthDetail->medical_history); ?> </td></tr>
	                        <tr><th> Family Medical History </th><td> <?php echo e($patient->patientHealthDetail->family_medical_history); ?> </td></tr>
	                        <tr><th> Important Note </th><td> <?php echo e($patient->patientHealthDetail->imp_note); ?> </td></tr>
	                    </tbody>
	                </table>
	            </div>
				<!-- <button class="btn btn-success">Follow</button> -->
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>