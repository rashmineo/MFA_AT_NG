<?php $__env->startSection('title', 'Patients'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add New Patient</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                   <a href="<?php echo e(url('/patient')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
            </div>
        </div>
        <br>
       <!--  <?php if($errors->any()): ?>                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>                    <?php echo e($error); ?>                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                    <?php endif; ?> -->
        <?php echo Form::open(['url' => '/patient', 'class' => 'form-horizontal', 'id'=>'patient_register', 'files' => true]); ?>


                        <?php echo $__env->make('patient_information.form',['pageType' =>'create'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        
                        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>