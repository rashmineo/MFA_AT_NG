<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use Illuminate\Database\Eloquent\SoftDeletes;



class PatientInformation extends Model
{
    use Notifiable,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'patient_information';
    protected $fillable = [
        'mrn','first_name', 'middle_name', 'last_name','guardian_name','dob','birth_time','gender','marital_status','blood_group','religion','occupation','organization_name','profile_pic',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];


    public function country(){
        return $this->belongsTo('App\Models\Country');
    }
    public function state(){
        return $this->belongsTo('App\Models\State');
    }
    public function city(){
        return $this->belongsTo('App\Models\City');
    }
    public function patientContact(){
        return $this->hasOne('App\Models\PatientContact','patient_id');
    }
    public function patientInsurance(){
        return $this->hasOne('App\Models\PatientInsurance','patient_id');
    }
    public function patientHealthDetail(){
        return $this->hasOne('App\Models\PatientHealthDetail','patient_id');
    }
    public function visitorInformation(){
        return $this->hasOne('App\Models\VisitorInformation','patient_id');
    }
    public function getProfilePicUrlAttribute() {    
    //dd($this->profile_pic);    
        return url('/').config('constants.PATIENT_PROFILE_PIC_PATH').$this->profile_pic; 
    }
    public static function boot()
    {
        parent::boot();

        self::created(function($model){
            // ... code here
            //dd($model->toArray());
            $MRN_number=PatientInformation::genrateMRN();
            //dd($MRN_number);
            self::find($model->id)->update(['mrn'=>$MRN_number]);
        });
    }
    public static function genrateMRN(){
        $last_mrn=PatientInformation::orderBy('id', 'desc')->first();
        $is_development = (config('app.env') == 'local' || config('app.env') == 'testing') ? true : false ;
        $mrn_alpha=config('constants.MRN_ALPHA');
        if($last_mrn==null){
            if($is_development){
                $new_mrn=$mrn_alpha.'Z000001';
            }else{
                $new_mrn=$mrn_alpha.'A000001';
            }
            
        }else{
            $search_str = $mrn_alpha.'Z'; 
            if($is_development){

                $last_mrn=PatientInformation::where('mrn','LIKE',"$search_str%")->orderBy('id', 'desc')->first();
                if($last_mrn==null){
                    $last_mrn_no=$mrn_alpha.'Z000000';
                 }   

            }else{
                $last_mrn=PatientInformation::where('mrn','NOT LIKE',"$search_str%")->orderBy('id', 'desc')->first();
                if($last_mrn==null){
                    $last_mrn_no=$mrn_alpha.'A000000';
                 }
            }
            if($last_mrn!=null){
                $last_mrn_no=$last_mrn->mrn;
            }
            //Split MRN
            $letter = $last_mrn_no[6];
            $number = (int) substr($last_mrn_no,7);

            if ($number==999999) {
              $letter++;
              $number = 1;
            }
            else {
              $number++;
            }
            $stspad=str_pad($number,6,"0",STR_PAD_LEFT);

            $mrn_alpha=config('constants.MRN_ALPHA');
            $new_mrn=$mrn_alpha.$letter.$stspad;
        }
        //dd($new_mrn);
        return $new_mrn;
    }
}
