<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;

class VisitorInformation extends Model
{
    use Notifiable,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'visitor_information';
    protected $fillable = [
        'patient_id','visitor_no',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];
    public function patientInformation()
    {
        return $this->belongsTo('App\Models\PatientInformation');
    }

    public static function boot()
    {
        parent::boot();

        self::created(function($model){
            // ... code here
            //dd($model->toArray());
            $visitor_number=VisitorInformation::genrateVN();
            self::find($model->id)->update(['visitor_no'=>$visitor_number]);
        });
    }
    public static function genrateVN(){
        $last_vn=VisitorInformation::orderBy('id', 'desc')->first();
        $is_development = (config('app.env') == 'local' || config('app.env') == 'testing') ? true : false ;
        $vn_alpha=config('constants.VN_ALPHA');
        if($last_vn==null){
            if($is_development){
                $new_vn=$vn_alpha.'Z00000001';
            }else{
                $new_vn=$vn_alpha.'A00000001';
            }
            
        }else{
            $search_str = $vn_alpha.'Z'; 
            if($is_development){
                $last_vn=VisitorInformation::where('visitor_no','LIKE',"$search_str%")->orderBy('id', 'desc')->first();
                if($last_vn==null){
                    $last_vn_no=$vn_alpha.'Z00000000';
                 }   
            }else{
                $last_vn=VisitorInformation::where('visitor_no','NOT LIKE',"$search_str%")->orderBy('id', 'desc')->first();
                if($last_vn==null){
                    $last_vn_no=$vn_alpha.'A00000000';
                 }
            }
            
            if($last_vn!=null){
                $last_vn_no=$last_vn->visitor_no;
            } 
            //dd($last_vn->toArray());   
            //Split MRN
            $letter = $last_vn_no[8];
            $number = (int) substr($last_vn_no,9);

            if ($number==99999999) {
              $letter++;
              $number = 1;
            }
            else {
              $number++;
            }
            $stspad=str_pad($number,8,"0",STR_PAD_LEFT);

            $vn_alpha=config('constants.VN_ALPHA');
            $new_vn=$vn_alpha.$letter.$stspad;
            //dd($new_vn);
        }
        return $new_vn;
    }
}