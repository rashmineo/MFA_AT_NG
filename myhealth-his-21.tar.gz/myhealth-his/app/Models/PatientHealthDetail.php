<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientHealthDetail extends Model
{
    use Notifiable,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'patient_health_detail';
    protected $fillable = [
        'patient_id','allergies_type', 'allergens', 'medical_history','family_medical_history','imp_note',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];
    public function patientInformation()
    {
        return $this->belongsTo('App\Models\PatientInformation');
        //Laravel automatically snake case your model 
        //so it will assume the foreign key is named user_id
    }
}
