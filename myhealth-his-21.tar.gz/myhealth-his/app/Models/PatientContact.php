<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientContact extends Model
{
    use Notifiable,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'patient_contact';
    protected $fillable = [
        'patient_id','current_address', 'current_city_id', 'current_state_id','current_country_id','current_pincode','permanent_address','permanent_country_id','permanent_state_id','permanent_city_id','permanent_pincode','phone_number','alt_phone_number','email','nationality','id_type','id_number',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];

    public function patientInformation()
    {
        return $this->belongsTo('App\Models\PatientInformation');
        //Laravel automatically snake case your model 
        //so it will assume the foreign key is named user_id
    }
    public function country(){
        return $this->belongsTo('App\Models\Country','current_country_id');
    }
    public function state(){
        return $this->belongsTo('App\Models\State','current_state_id');
    }
    public function city(){
        return $this->belongsTo('App\Models\City','current_city_id');
    }
    public function permanentCountry(){
        return $this->belongsTo('App\Models\Country','permanent_country_id');
    }
    public function permanentState(){
        return $this->belongsTo('App\Models\State','permanent_state_id');
    }
    public function permanentCity(){
        return $this->belongsTo('App\Models\City','permanent_city_id');
    }
}
