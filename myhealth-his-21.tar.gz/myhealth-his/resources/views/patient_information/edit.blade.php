@extends('adminlte::page')

@section('title', 'Edit Patient')

@section('content_header')
    <h1>Edit Patient</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Edit Patient #{{ $patient->id }}</div>
                    <div class="panel-body">
                        <a href="{{ url('/patient') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        {!! Form::model($patient, [
                            'id'=>'patient_register',
                            'method' => 'PATCH',
                            'url' => ['/patient', $patient->id],
                            'class' => 'form-horizontal',
                            'files' => true
                        ]) !!}

                        @include ('patient_information.form', ['submitButtonText' => 'Update','pageType' =>'edit'])

                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
