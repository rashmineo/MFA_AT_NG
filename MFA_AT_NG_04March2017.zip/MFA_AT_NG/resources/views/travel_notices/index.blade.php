@extends('adminlte::page')

@section('title', 'Manage Travel Notices')

@section('content_header')
    <h1>Manage Travel Notices</h1>
@stop

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Travel Notices</strong>
                    </div>
                    <div class="panel-body">
                        <a href="{{ url('/travel-notices/create') }}" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>

                        {!! Form::open(['method' => 'GET', 'url' => '/travel-notices', 'class' => 'navbar-form navbar-right', 'role' => 'search'])  !!}
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        {!! Form::close() !!}

                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Date</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @php $autoNum=1 @endphp    
                                @foreach($travelNoticies as $travelNotice)
                                    <tr>
                                        <td>{{ $autoNum++ }}</td>
                                        <td>{{ $travelNotice->updated_at->format('d-m-Y') }}</td>
                                        <td>{{ $travelNotice->description }}</td>
                                        <td>{!! ($travelNotice->status==1) ? '<i class="fa fa-check"><i>' : '<i class="fa fa-times"><i>' !!}</td>
                                        <td class="actions">                                            
                                            <a href="{{ url('/travel-notices/'.$travelNotice->id.'/edit') }}" title="Edit Travel Notice"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
                                            <a href="{{ url('/travel-notices/'.$travelNotice->id.'/status') }}" title="Change Travel Notice Status"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle" aria-hidden="true"></i>Status</button></a>
                                            <!--a href="{{ url('/travel-notices/'.$travelNotice->id.'/delete') }}" title="Edit Travel Notice"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button></a-->
                                            {!! Form::open(['method'=>'DELETE','url'=> ['/travel-notices/'.$travelNotice->id],'style' => 'display:inline']) !!}
                                                {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete',[
                                                    'type'=>'submit',
                                                    'class'=>'btn btn-danger btn-xs',
                                                    'title'=>'Delete Travel Notice',
                                                    'onclick' => 'return confirm("Confirm delete?")'
                                                ]) !!}
                                            {!! Form::close() !!}
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> {!! $travelNoticies->appends(['search' => Request::get('search')])->render() !!} </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
