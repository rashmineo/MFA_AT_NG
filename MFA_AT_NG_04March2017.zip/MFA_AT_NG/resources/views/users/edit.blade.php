@extends('adminlte::page')

@section('title', 'Edit Profile')

@section('content_header')
    <h1>Edit Profile</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Edit Profile #{{ $adminuser->id }}</div>
                    <div class="panel-body">
                        <a href="{{ url('/adminusers') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        {!! Form::model($adminuser, [
                            'method' => 'PATCH',
                            'url' => ['/adminusers', $adminuser->id],
                            'class' => 'form-horizontal',
                            'files' => true
                        ]) !!}

                        @include ('users.form', ['submitButtonText' => 'Update','pageType' =>'edit'])

                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
