@extends('adminlte::page')

@section('title','Add New FAQ')

@section('content')

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
                <div class="panel-heading">Create New FAQ</div>
                    <div class="panel-body">
                    	<a href="{{ url('/faqs') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        {!! Form::open(['url' => '/faqs', 'class' => 'form-horizontal', 'files' => true]) !!}

                        @include ('faqs.form')

                        {!! Form::close() !!}
                 	</div>
            </div>    
        </div>    
	</div>
</div>

@endsection