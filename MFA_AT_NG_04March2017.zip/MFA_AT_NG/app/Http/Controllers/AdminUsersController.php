<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Country;
use App\City;
use App\State;
use Illuminate\Support\Facades\Validator;

class AdminUsersController extends Controller
{

    public function index(Request $request)
    {
        //$keyword = $request->get('search');
        $perPage=5;

        $adminusers=User::orderBy('id','DESC')->paginate($perPage);
        
        return view('users.index',['adminusers'=>$adminusers])->with('i',($request->input('page','1')-1)*5);

    }

    public function create()
    {
        /*$countries=Country::pluck('name','id')->toArray();
        //dd($countries);
        return view('users.create',compact('countries'));*/


        $countries = Country::pluck('name','id')->toArray();
        $states = [''=>'Select state'];
        $cities = [''=>'Select city'];
        //dd($cities);
        return view('users.create',compact('countries','states','cities'));
    }

    public function store(Request $request)
    {
        //dd($request->input('country_id'));
        $this->validate($request,[
            'title'=>'required',
            'first_name'=>'required|min:3',
            'last_name'=>'required|min:3',
            'email'=>'required|email|unique:users,email',
            'phone_no'=>'required|numeric',
            'country_id'=>'required',
            'state_id'=>'required',
            'city_id'=>'required',
            'username'=>'required|alpha_num|min:4|unique:users,username',
            'password'=>'required|min:6',
            'confirm_password'=>'required|min:6|same:password',
        ]);

        User::create([
            'user_role_id' =>1,
            'name' => 'test',
            'title'=>$request->input('title'),
            'first_name'=>$request->input('first_name'),
            'last_name'=>$request->input('last_name'),
            'email'=>$request->input('email'),
            'phone_no'=>$request->input('phone_no'),
            'country_id'=>$request->input('country_id'),
            'state_id'=>$request->input('state_id'),
            'city_id'=>$request->input('city_id'),
            'username'=>$request->input('username'),
            'password'=>bcrypt($request->input('password')),
        ]);


        return redirect()->route('adminusers.index')->with('success','User added successfully.');
    }

    public function show($id)
    {
        $adminuser = User::find($id);
        return view('users.show',compact('adminuser'));
    }

    public function edit($id)
    {
        $adminuser = User::find($id);
        $countries = Country::pluck('name','id')->toArray();
        $states = State::where('country_id',$adminuser->country_id)->pluck('name','id')->toArray();
        $cities = City::where('state_id',$adminuser->state_id)->pluck('name','id')->toArray();
        //dd($cities);
        return view('users.edit',compact('adminuser','countries','states','cities'));
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
