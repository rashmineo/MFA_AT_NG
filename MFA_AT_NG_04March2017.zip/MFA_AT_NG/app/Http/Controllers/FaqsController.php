<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Faq;
use Auth;
use Carbon\Carbon;
use DB;

class FaqsController extends Controller
{
    
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 5;

        if(!empty($keyword)){
            //DB::enableQueryLog();
            $faqs = Faq::where('faq_query','Like',"%$keyword%")->orderBy('id','DESC')
                        ->paginate($perPage);
            //dd(DB::getQueryLog());
        }else{
            $faqs = Faq::orderBy('id','Desc')->paginate($perPage);
        }

        return view('faqs.index',['faqs'=>$faqs])->with('i',($request->input('page',1)-1)*5);
    }

    public function create()
    {
        return view('faqs.create');
    }


    public function store(Request $request)
    {
        $this->validate($request,[
            'faq_query'=>'required|min:3'
            ]);
        $curr_date=Carbon::Now();
        $current_dateTime=$curr_date->toDateTimeString();
        $faq_status =1;
        $request->request->add(['faq_status'=>$faq_status,'faq_date'=>$current_dateTime]);
        Faq::create($request->all());
        return redirect()->route('faqs.index')->with('success','Added successfully.');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $faq = Faq::find($id);
        return view('faqs.edit',compact('faq'));
    }

    
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'faq_query'=>'required|min:3'
            ]);
        Faq::find($id)->update($request->all());
        return redirect()->route('faqs.index')->with('success','Record updated successfully.');
    }

    
    public function destroy($id)
    {
        //
    }
}
