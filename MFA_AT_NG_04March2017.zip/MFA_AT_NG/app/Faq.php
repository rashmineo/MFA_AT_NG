<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Faq extends Model
{
    use SoftDeletes;

    protected $table = 'faqs';
    public $fillable = ['faq_query','faq_date','faq_status'];
    protected $dates = ['deleted_at'];
}
