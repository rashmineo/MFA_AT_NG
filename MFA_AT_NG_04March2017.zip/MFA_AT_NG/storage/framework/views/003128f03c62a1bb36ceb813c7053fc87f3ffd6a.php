<?php $__env->startSection('title', 'Manage Travel Notices'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Manage Travel Notices</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Travel Notices</strong>
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/travel-notices/create')); ?>" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>

                        <?php echo Form::open(['method' => 'GET', 'url' => '/travel-notices', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>


                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Date</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php  $autoNum=1  ?>    
                                <?php $__currentLoopData = $travelNoticies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travelNotice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($autoNum++); ?></td>
                                        <td><?php echo e($travelNotice->updated_at->format('d-m-Y')); ?></td>
                                        <td><?php echo e($travelNotice->description); ?></td>
                                        <td><?php echo ($travelNotice->status==1) ? '<i class="fa fa-check"><i>' : '<i class="fa fa-times"><i>'; ?></td>
                                        <td class="actions">                                            
                                            <a href="<?php echo e(url('/travel-notices/'.$travelNotice->id.'/edit')); ?>" title="Edit Travel Notice"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
                                            <a href="<?php echo e(url('/travel-notices/'.$travelNotice->id.'/status')); ?>" title="Change Travel Notice Status"><button class="btn btn-warning btn-xs"><i class="fa fa-times-circle" aria-hidden="true"></i>Status</button></a>
                                            <!--a href="<?php echo e(url('/travel-notices/'.$travelNotice->id.'/delete')); ?>" title="Edit Travel Notice"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button></a-->
                                            <?php echo Form::open(['method'=>'DELETE','url'=> ['/travel-notices/'.$travelNotice->id],'style' => 'display:inline']); ?>

                                                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete',[
                                                    'type'=>'submit',
                                                    'class'=>'btn btn-danger btn-xs',
                                                    'title'=>'Delete Travel Notice',
                                                    'onclick' => 'return confirm("Confirm delete?")'
                                                ]); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> <?php echo $travelNoticies->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>