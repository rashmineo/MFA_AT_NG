<?php $__env->startSection('title','Manage Your Profile'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Manage Your Profile</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong>Manage Your Profile</strong>
                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/adminusers/')); ?>" class="btn btn-warning btn-xs" title="Add New Blog">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i> Back
                        </a>
                        <br />
                        <br />
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td><?php echo e($adminuser->id); ?></td>
                                    </tr>
                                    <tr>
                                         <th>Title</th><td><?php echo e($adminuser->title); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Name</th><td><?php echo e(ucfirst($adminuser->first_name)." ". ucfirst($adminuser->last_name)); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Email</th><td><?php echo e($adminuser->email); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Phone No.</th><td><?php echo e($adminuser->phone_no); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>Country</th><td><?php echo e(isset($adminuser->country->name) ? $adminuser->country->name : '-'); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>State</th><td><?php echo e(isset($adminuser->state->name) ? $adminuser->state->name : '-'); ?></td>
                                    </tr> 
                                    <tr>
                                         <th>City</th><td><?php echo e(isset($adminuser->city->name) ? $adminuser->city->name : '-'); ?></td>
                                    </tr> 
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>