<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('title', array('MR' => 'Mr','MISS'=>'Miss','MRS'=>'Mrs'),null,['class' => 'form-control']);; ?>

        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('first_name', 'First Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('first_name', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('last_name', 'Last Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('last_name', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('phone_no') ? 'has-error' : ''); ?>">
    <?php echo Form::label('phone_no', 'Phone Number', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('phone_no', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('phone_no', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('country_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('country_id', 'Country', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
       <!--  <?php echo Form::select('country',array('class'=>'form-control countries','id'=>'country_id','style'=>'width:350px;'));; ?> -->

       <?php echo Form::select('country_id', array_merge(['' => 'Please Select'], $countries), null, ['class' => 'form-control countries','id'=>"country_id"]); ?>


        <?php echo $errors->first('country', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('state_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('state_id', 'State', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('state_id', array_merge(['' => 'Please Select'], $states), null, ['class' => 'form-control states','id'=>"state_id"]); ?>


        <!-- <?php echo Form::select('state_id', ['Select State'], null, ['class' => 'form-control states','id'=>"state_id"]); ?>

 -->
        <?php echo $errors->first('state', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('city_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('city_id', 'City', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('city_id', array_merge(['' => 'Please Select'], $cities), null, ['class' => 'form-control cities','id'=>"city_id"]); ?>


     <!--    <?php echo Form::select('city_id', ['Select City'], null, ['class' => 'form-control cities','id'=>"city_id"]); ?>

 -->

        <?php echo $errors->first('city', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
    <?php echo Form::label('username', 'Username', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('username', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('username', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php if(isset($pageType) && $pageType!='edit'): ?>
<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('password', 'Password', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::password('password', ['class' => 'form-control']); ?>

        <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('confirm_password', 'Confirm Password', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::password('confirm_password', ['class' => 'form-control']); ?>

        <?php echo $errors->first('confirm_password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php endif; ?>
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
<script type="text/javascript">
    //alert('<?php echo e(url("api/get-states")); ?>');
    function ajaxCall() {
        this.send = function(data, url, method, success, type) {
          type = type||'json';
          var successRes = function(data) {
              success(data);
          };

          var errorRes = function(e) {
              console.log(e);
              alert("Error found \nError Code: "+e.status+" \nError Message: "+e.statusText);
          };
            $.ajax({
                url: url,
                type: method,
                data: data,
                success: successRes,
                error: errorRes,
                dataType: type,
                timeout: 60000
            });

          }

        }

function locationInfo() {
    var rootUrl = "api.php";
    var call = new ajaxCall();
    this.getCities = function(id) {
        $(".cities option:gt(0)").remove();
        var url = '<?php echo e(url("api/get-cities")); ?>';
        var method = "post";
        var data = {'state_id':id};
        $('.cities').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.cities').find("option:eq(0)").html("Select City");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.cities').append(option);
                });
                $(".cities").prop("disabled",false);
            }
            else{
                 alert(data.msg);
            }
        });
    };

    this.getStates = function(id) {
        $(".states option:gt(0)").remove(); 
        $(".cities option:gt(0)").remove(); 
        //var url = rootUrl+'?type=getStates&countryId=' + id;
        var url = '<?php echo e(url("api/get-states")); ?>';
        var method = "post";
        var data = {'country_id':id};
        $('.states').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.states').find("option:eq(0)").html("Select State");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.states').append(option);
                });
                $(".states").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

    this.getCountries = function() {
        var url = '<?php echo e(url("api/get-countries")); ?>';
        var method = "post";
        var data = {};
        $('.countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.countries').append(option);
                });
                $(".countries").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

}

$(function() {
var loc = new locationInfo();
loc.getCountries();
 $(".countries").on("change", function(ev) {
        var countryId = $(this).val();
        if(countryId != ''){
        loc.getStates(countryId);
        }
        else{
            $(".states option:gt(0)").remove();
        }
    });
 $(".states").on("change", function(ev) {
        var stateId = $(this).val();
        if(stateId != ''){
        loc.getCities(stateId);
        }
        else{
            $(".cities option:gt(0)").remove();
        }
    });
});

</script>


